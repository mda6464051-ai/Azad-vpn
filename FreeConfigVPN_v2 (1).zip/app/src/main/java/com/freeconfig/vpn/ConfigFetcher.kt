
package com.freeconfig.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

object ConfigFetcher {
    // منابع بدون نیاز به سرور - هر 10 دقیقه آپدیت میشن
    private val SOURCES = mapOf(
        VpnType.V2RAY to listOf(
            "https://raw.githubusercontent.com/barry-far/V2ray-Configs/main/Sub1.txt",
            "https://raw.githubusercontent.com/mahdibland/V2RayAggregator/main/sub/sub_merge.txt",
            "https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/Splitted-By-Protocol/vless.txt"
        ),
        VpnType.SHADOWSOCKS to listOf(
            "https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/Splitted-By-Protocol/shadowsocks.txt",
            "https://raw.githubusercontent.com/mfuu/v2ray/master/v2ray"
        ),
        VpnType.TROJAN to listOf(
            "https://raw.githubusercontent.com/Epodonios/v2ray-configs/main/Splitted-By-Protocol/trojan.txt",
            "https://raw.githubusercontent.com/barry-far/V2ray-Configs/main/Sub3.txt"
        )
    )

    suspend fun fetchAll(): List<VpnConfig> = withContext(Dispatchers.IO) {
        val all = mutableListOf<VpnConfig>()
        SOURCES.forEach { (type, urls) ->
            urls.forEach { url ->
                try {
                    val text = URL(url).readText()
                    text.lines().forEach { line ->
                        parse(line.trim(), type)?.let { all.add(it) }
                    }
                } catch (e: Exception) {}
            }
        }
        all.shuffled().take(150) // 150 کانفیگ برتر برای سرعت
    }

    private fun parse(link: String, type: VpnType): VpnConfig? {
        if (link.isEmpty()) return null
        return when {
            link.startsWith("vless://") || link.startsWith("vmess://") -> VpnConfig(link, VpnType.V2RAY)
            link.startsWith("ss://") -> VpnConfig(link, VpnType.SHADOWSOCKS)
            link.startsWith("trojan://") || link.startsWith("tuic://") || link.startsWith("wireguard://") -> VpnConfig(link, VpnType.TROJAN)
            else -> null
        }
    }
}
