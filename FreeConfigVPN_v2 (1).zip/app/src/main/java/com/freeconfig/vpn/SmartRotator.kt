
package com.freeconfig.vpn

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket

class SmartRotator {
    var configs = mutableListOf<VpnConfig>()

    // ساختار 1: V2Ray, ساختار 2: SS, ساختار 3: Trojan
    fun getBestByType(type: VpnType): VpnConfig? {
        return configs.filter { it.type == type && it.isWorking }
                      .sortedBy { it.ping }
                      .firstOrNull()
    }

    suspend fun testAndSort() = withContext(Dispatchers.IO) {
        configs.forEach { config ->
            config.ping = testPing(config)
            config.isWorking = config.ping < 1500
        }
        configs.sortBy { it.ping }
    }

    private fun testPing(config: VpnConfig): Int {
        return try {
            // استخراج هاست از لینک برای تست سریع
            val host = Regex("@(.+?):").find(config.link)?.groupValues?.get(1) ?: return 9999
            val port = Regex(":(\\d+)").find(config.link)?.groupValues?.get(1)?.toInt() ?: 443
            val socket = Socket()
            val start = System.currentTimeMillis()
            socket.connect(InetSocketAddress(host, port), 2000)
            socket.close()
            (System.currentTimeMillis() - start).toInt()
        } catch (e: Exception) { 9999 }
    }

    fun onFailed(failed: VpnConfig): VpnConfig? {
        failed.isWorking = false
        // خودترمیمی: از همون ساختار، بعدی رو بده
        return getBestByType(failed.type)
    }
}
