
package com.freeconfig.vpn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val rotator = SmartRotator()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            var status by remember { mutableStateOf("در حال دریافت کانفیگ های رایگان...") }
            var currentConfig by remember { mutableStateOf<VpnConfig?>(null) }
            var v2rayCount by remember { mutableStateOf(0) }
            var ssCount by remember { mutableStateOf(0) }
            var trojanCount by remember { mutableStateOf(0) }
            val scope = rememberCoroutineScope()

            LaunchedEffect(Unit) {
                rotator.configs = ConfigFetcher.fetchAll().toMutableList()
                rotator.testAndSort()
                v2rayCount = rotator.configs.count { it.type == VpnType.V2RAY && it.isWorking }
                ssCount = rotator.configs.count { it.type == VpnType.SHADOWSOCKS && it.isWorking }
                trojanCount = rotator.configs.count { it.type == VpnType.TROJAN && it.isWorking }
                status = "آماده اتصال - ${rotator.configs.count { it.isWorking }} کانفیگ فعال"
            }

            MaterialTheme {
                Column(Modifier.padding(20.dp)) {
                    Text("FreeConfig VPN - بدون سرور", style = MaterialTheme.typography.headlineMedium)
                    Spacer(Modifier.height(20.dp))
                    Card { Column(Modifier.padding(16.dp)) {
                        Text("ساختار 1 (V2Ray): $v2rayCount فعال")
                        Text("ساختار 2 (Shadowsocks): $ssCount فعال")
                        Text("ساختار 3 (Trojan): $trojanCount فعال")
                    }}
                    Spacer(Modifier.height(20.dp))
                    Text(status)
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = {
                        scope.launch {
                            val best = rotator.getBestByType(VpnType.V2RAY) 
                                ?: rotator.getBestByType(VpnType.TROJAN)
                            currentConfig = best
                            // اینجا به LibV2ray وصل شو
                            // V2RayServiceManager.startV2ray(best.link)
                            status = "متصل شد به: ${best?.link?.take(30)}..."
                        }
                    }) { Text("اتصال هوشمند") }

                    currentConfig?.let {
                        Spacer(Modifier.height(10.dp))
                        Text("کانفیگ فعلی: ${it.type} | پینگ: ${it.ping}ms")
                    }
                }
            }
        }
    }
}
