
# FreeConfig VPN - بدون نیاز به سرور

## ویژگی ها
- 3 ساختار جدا: V2RAY / SHADOWSOCKS / TROJAN
- 150 کانفیگ رایگان از گیت هاب
- خودترمیمی: اگر کانفیگ خراب شد، خودکار عوض میشه
- بدون سرور اختصاصی

## نصب
1. Android Studio باز کن
2. dependencies:
   implementation 'com.github.2dust:libv2ray:1.0'
   implementation 'org.jetbrains.kotlinx:kotlinx-coroutines-android:1.7.3'
   implementation 'androidx.compose.material3:material3'

3. در AndroidManifest.xml:
   <uses-permission android:name="android.permission.INTERNET" />
   <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

4. Build -> APK

## چطور کار میکنه؟
اپ هر بار که باز میشه از 5 منبع Raw گیت هاب کانفیگ جدید میگیره، تست پینگ میکنه و بهترین رو وصل میکنه.
